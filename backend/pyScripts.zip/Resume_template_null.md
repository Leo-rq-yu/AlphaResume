---
name: 填写姓名
header:
  - text: <span class="iconify" data-icon="tabler:phone"></span> 填写电话
  - text: <span class="iconify" data-icon="tabler:mail"></span> 填写邮箱
    link: mailto:renovamenzxh@gmail.com
  - text: <span class="iconify" data-icon="tabler:brand-wechat"></span> 填写微信号
  - text: <span class="iconify" data-icon="charm:age"></span> age:填写年龄
  - text: <span class="iconify" data-icon="la:city"></span> 填写城市，国家
    newLine: true
---
---

## 教育经历

**填写学校名称**
  ~ 填写城市, 国家

填写专业(填写学历层次)
  ~ 开始时间 - 结束时间 

**GPA:** 
  ~ **学业排名:** 
  ~ **获奖记录:** 

**主修课程:**

## 职业经历  

**填写公司(填写城市, 国家)**
  ~ 填写部门
  ~ **填写实习岗位**
  ~ 开始时间 - 结束时间

- 填写工作描述1
- 填写工作描述2
- 填写工作描述3

## 项目经历  

**填写项目名称(填写城市，国家)**
  ~ 填写项目角色
  ~ 开始时间 - 结束时间

- **项目描述:** 
- **项目职责:** 
- **项目成就:** 
- **项目链接:** 

## 专利/论文

**填写论文名称**
  ~ 填写作者顺序
  ~ 填写发表时间

- **期刊/会议:**  
- **研究描述:** 
- **DOI/链接:** 

**填写专利名称**
  ~ 填写专利号
  ~ 填写授权时间

- **专利描述:**

## 获奖与证书

**填写奖项名称(填写奖项级别)** 
  ~ 填写获奖机构
  ~ 填写获奖时间


## 技能

**Programming Languages:** 填写会使用的编程语言

**Tools and Frameworks:** 填写会使用的工具与框架

**Languages:** 填写语言成绩